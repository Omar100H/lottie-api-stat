# Lottie to TGS Converter API

## Endpoint

**POST** `/convert`

**Body** (JSON):
```json
{
  "url": "https://example.com/path/to/lottie.json"
}
```

Returns: `.tgs` file for download.

### Requires: `lottie_convert.py` from Telegram's Lottie tools (Python, Node.js, CairoSVG).
