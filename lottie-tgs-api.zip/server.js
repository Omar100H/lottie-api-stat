const express = require('express');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

app.post('/convert', async (req, res) => {
  const { url } = req.body;
  if (!url) return res.status(400).json({ error: 'Missing URL' });

  try {
    const response = await axios.get(url);
    const jsonData = response.data;
    const tempDir = './tmp';
    const jsonPath = path.join(tempDir, 'input.json');
    const tgsPath = path.join(tempDir, 'output.tgs');

    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir);
    fs.writeFileSync(jsonPath, JSON.stringify(jsonData));

    exec(`lottie_convert.py ${jsonPath} ${tgsPath}`, (error, stdout, stderr) => {
      if (error) {
        return res.status(500).json({ error: stderr || 'Conversion failed' });
      }
      res.download(tgsPath, 'animation.tgs', () => {
        fs.rmSync(tempDir, { recursive: true, force: true });
      });
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
